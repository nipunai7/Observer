package com.company;

public interface Observer{
    void notifyObserver(String news);
}
