package com.company.observerPattern;

public interface Observer {
    void update(String title,String categoryName);
}
